import React, { useState, useEffect} from "react";
import { memo } from "react";
import moment from 'moment';
import { Button, Space } from 'antd';
import "./education.css";
import {
  Accordion,
  AccordionItem,
  AccordionItemHeading,
  AccordionItemButton,
  AccordionItemPanel,
} from "react-accessible-accordion";
import "react-accessible-accordion/dist/fancy-example.css";
import { useQuill } from 'react-quilljs';
import 'quill/dist/quill.snow.css';
import ReactQuill from "react-quill";
import DOMPurify from 'isomorphic-dompurify';
import "react-quill/dist/quill.snow.css";
import axios from 'axios';
import { Select, Dropdown, Menu } from 'antd';
import { Input } from 'antd';
import { DatePicker } from 'antd';
const { TextArea } = Input;

const baseURL = "http://localhost:3001";
const year_options = [];
for (let year = 2023; year >= 1950; year--) {
  year_options.push({
    value:  year,
    label:  year,
  })

}
const modules = {
  toolbar: [
    ['bold', 'italic', 'underline'],
    [{'list': 'ordered'}, {'list': 'bullet'}],
    ['link'],
  ],
  clipboard: {
    matchVisual: false,
  },
};

function EducationForm({ detail }) {
  console.log("hello certi 3")
  const [isChecked_edu, setIschecked_edu] = useState(false);
  const [showEmployment_edu, setShowEmployment_edu] = useState(-1); // initialize state with -1
  const [employment_edu, setEmployment_edu] = useState([]);
  const [nationalityArray_edu, setNationalityArray_edu] = useState([]);
  const [stateArray_edu, setStateArray_edu] = useState([]);
  const [country_edu, setCountry_edu] = useState('');
  const [specializationArray_edu, setSpecializationArray_edu] = useState([]);
  const [showSpecializationMessage_edu, setShowSpecializationMessage_edu] = useState(false);
  const [selectedSpecializationItem_edu, setSelectedSpecializationItem_edu] = useState(null);
  const [collegeArray_edu, setCollegeArray_edu] = useState([]);
  const [showCollegeMessage_edu, setShowCollegeMessage_edu] = useState(false);
  const [selectedCollegeItem_edu, setSelectedCollegeItem_edu] = useState(null);
  const [userInfo_edu, setuserInfo_edu] = useState({
    title: "",
    description: "",
    information: "",
  });

  useEffect(() => {
    // Function to make the API call
    const fetchData = async () => {
      try {
        let countryArray_edu = []
        let specializationTArray_edu = []
        let collegeTArray_edu = []

        let getData_edu = await axios.get(`${baseURL}/api/v1/profileupdate/103`);
        if(getData_edu.data.data.educations){
          let exp_array = getData_edu.data.data.educations;
          let employment_array = []
          console.log(exp_array, "course_array")
          exp_array.map((obj, index) => {  
            let exp_obj = {
              primary_qualification: obj.primary_qualification,
              secondary_qualification: obj.secondary_qualification,
              specialization: obj.specialization,
              college: obj.college,
              percentage: obj.percentage,
              cgpa: obj.cgpa,
              year_of_complete: obj.year_of_complete ? obj.year_of_complete : null
            };
             employment_array.push(exp_obj)
          })
          setEmployment_edu(employment_array)
          // detail(employment_array, "getArray")
         // setStates(employment_array)
     
          
       }
        const response_edu = await axios.get(`${baseURL}/api/v1/primary_qualification`)
        console.log(response_edu.data.data, "res")
        for (let i=0; i<response_edu.data.data.length; i++){
          let countryList =  {
            value: response_edu.data.data[i].id,
            label: response_edu.data.data[i].english,
          }
          countryArray_edu.push(countryList)
        }
        setNationalityArray_edu(countryArray_edu)
        console.log(countryArray_edu, "array")
        const spe_response_edu = await axios.get(`${baseURL}/api/v1/specialization`);
        console.log(spe_response_edu.data.data, "res")
        for (let i=0; i<spe_response_edu.data.data.length; i++){
          let specializationList =  {
            value: spe_response_edu.data.data[i].id,
            label: spe_response_edu.data.data[i].english,
          }
          specializationTArray_edu.push(specializationList)
        }
        setSpecializationArray_edu(specializationTArray_edu)
        const college_response_edu = await axios.get(`${baseURL}/api/v1/college`);
        console.log(college_response_edu.data.data, "res")
        for (let i=0; i<college_response_edu.data.data.length; i++){
          let collegeList =  {
            value: college_response_edu.data.data[i].id,
            label: college_response_edu.data.data[i].english,
          }
          collegeTArray_edu.push(collegeList)
        }
        setCollegeArray_edu(collegeTArray_edu)

        // Process the data or update the state
      } catch (error) {
        // Handle any errors
      }
    };

    // Call the API when the component is mounted
    fetchData();
  }, []); 

  function handleCountryChange_edu(event, index, field) {
    console.log(event, 
      "hhhhhh")
    setCountry_edu(event);
    const fetchData = async () => {
      try {
        let stateTArray = []
        const response = await axios.get(`http://localhost:3001/api/v1/secondary_qualification?id=${event}`)
        console.log(response, "res")
        for (let i=0; i<response.data.data.length; i++){
          let stateList =  {
            value: response.data.data[i].id,
            label: response.data.data[i].english,
          }
          stateTArray.push(stateList)
        }
        setStateArray_edu(stateTArray)

        handleEmploymentChange_edu(event, index, field)
      
        // Process the data or update the state
      } catch (error) {
        // Handle any errors
      }
    };
    fetchData();
  }

  // const handleCompanyLeave = () => {
  //   setShowCompanyMessage(false);
  // }
  const handleSpecializationChange_edu = (value) => {
    setSelectedSpecializationItem_edu(value[0]);
    setShowSpecializationMessage_edu(false);
  };

  const handleSpecializationDropdownVisibleChange_edu = (visible) => {
    if (visible && selectedSpecializationItem_edu) {
      setShowSpecializationMessage_edu(true);
    }
  };

  const renderSpecializationMenu_edu = () => {
    if (showSpecializationMessage_edu) {
      return (
        <Menu>
          <Menu.Item key="1" disabled>
               You can select only one item
          </Menu.Item>
        </Menu>
      );
    }
    return null;
  };

  const handleCollegeChange_edu = (value) => {
    setSelectedCollegeItem_edu(value[0]);
    setShowCollegeMessage_edu(false);
  };

  const handleCollegeDropdownVisibleChange_edu = (visible) => {
    console.log("visiiiii")
    if (visible && selectedCollegeItem_edu) {
      setShowCollegeMessage_edu(true);
    }
  };

  const renderCollegeMenu_edu = () => {
    if (showCollegeMessage_edu) {
      return (
        <Menu>
          <Menu.Item key="1" disabled>
               You can select only one item
          </Menu.Item>
        </Menu>
      );
    }
    return null;
  };

  const handleCheckboxChange_edu = () => {
    setIschecked_edu(!isChecked_edu);
  }
  const handleAddEmployment_edu = () => {
    setShowEmployment_edu(-1); // reset state when adding a new item
    setEmployment_edu([
      ...employment_edu,
      {
        primary_qualification: "",
        secondary_qualification: "",
        specialization: "",
        college: "",
        percentage: "",
        cgpa: "",
        year_of_complete: ""
      },
    ]);
  };

  const handleDeleteHobby_edu = (index) => {
    const newEmployment = [...employment_edu];
    newEmployment.splice(index, 1);
    setEmployment_edu(newEmployment);
    //detail(newEmployment, "updateArray");
  };
  
  const handleToggleAccordion_edu = (index) => {
    if (showEmployment_edu === index) {
      setShowEmployment_edu(-1); // toggle off if same item is clicked again
    } else {
      setShowEmployment_edu(index);
    }
  };

  const handleHobbyChange_edu = (event, index, field) => {
    const newEmployment = [...employment_edu];
    newEmployment[index][field] = event.target.value;
    setEmployment_edu(newEmployment);
  };
  const handleEmploymentChange_edu = (event, index, field) => {
    var summary_value;
    if(field === 'job_description' || field === 'job_summary'){
      const newDescription = {...userInfo_edu};
      newDescription.description = event;
      setuserInfo_edu({ ...userInfo_edu, description: event });
      const sanitizedHtml = DOMPurify.sanitize( newDescription.description)
      const formattedText = <div dangerouslySetInnerHTML={{__html: sanitizedHtml}}></div>;
      summary_value = formattedText
    } 
    else if(field === 'primary_qualification' || field === 'secondary_qualification' || field === 'specialization' || field === 'year_of_complete'){
      summary_value = event
    }
    else{
      summary_value = event.target.value
    }
    const newEmployment = [...employment_edu];
    newEmployment[index][field] = summary_value;
    setEmployment_edu(newEmployment);
  };

  const handleSubmit_edu = (event) => {
    event.preventDefault();
  };

  return (
    <div onSubmit={handleSubmit_edu} className="employment">
      <div className="row col-md-12 " >
        <h2 className="resume-title">Education</h2>
        <p className="sub-title">
          A varied education on your resume sums up the value that your
          learnings and background will bring to job.
        </p>
      </div>

      {employment_edu.map((hobby, index) => (
        <div key={index}>
          <Accordion allowZeroExpanded={true}>
            <AccordionItem>
              <AccordionItemHeading>
                <AccordionItemButton onClick={() => handleToggleAccordion_edu(index)}>
                  Education titles {index + 1}{" "}
                  <button
                    type="button"
                    className="btn btn-default float-right "
                    onClick={() => handleDeleteHobby_edu(index)}
                  >
                    <i className="fa fa-trash"></i>
                  </button>
                </AccordionItemButton>
              </AccordionItemHeading>
              <AccordionItemPanel>
                <div className="row row_employment col-md-12">
                  <div className="col-md-6  inputField">
                  <label htmlFor="primary_qualification">Highest Qualification</label>
                <Select
                    id="primary_qualification"
                    value={hobby.primary_qualification}
                    showSearch
                    placeholder="Select primary_qualification"
                    onChange={(event) => handleCountryChange_edu(event, index, "primary_qualification")}
                    options={nationalityArray_edu}
                   /> 
                  </div>
                  <div className="col-md-6 inputField">
                  <label htmlFor="degree_name">Degree Name</label>
                  <Select
                    showSearch
                    value={hobby.secondary_qualification}
                    placeholder="Select Degree"
                    onChange={(event) => handleEmploymentChange_edu(event, index, "secondary_qualification")}
                    options={stateArray_edu}
                    autoComplete= 'off'
                   />

                  </div>
                  <div className="col-md-6 inputField">
                    <label htmlFor="specialization">Select Specialization</label>
                  <Dropdown
                          overlay={renderSpecializationMenu_edu}
                          visible={showSpecializationMessage_edu}
                          onVisibleChange={handleSpecializationDropdownVisibleChange_edu}
                       >
                        <Select
                            mode="tags"
                            style={{ width: '100%' }}
                            placeholder="Search for a Specialization"
                            onChange={(event) => handleEmploymentChange_edu(event, index, "specialization")}
                            value= {hobby.specialization}
                            showSearch // Enable searching
                            autoComplete="off" // Disable autocomplete
                     >
                     {specializationArray_edu.map((option) => (
                         <Select.Option key={option.value} value={option.label}>
                              {option.label}
                         </Select.Option>
                    ))}
                    </Select>
                      </Dropdown>
                  </div>
                  <div className="col-md-6 inputField">
                    <label htmlFor="college_name">College Name</label>
                  <Dropdown
                           overlay={renderCollegeMenu_edu}
                           visible={showCollegeMessage_edu}
                           onVisibleChange={handleCollegeDropdownVisibleChange_edu}
                       >
                        <Select
                            mode="tags"
                            style={{ width: '100%' }}
                            placeholder="Search for a College"
                            onChange={(event) => handleEmploymentChange_edu(event, index, "college")}
                            value = {hobby.college}
                            showSearch // Enable searching
                            autoComplete="off" // Disable autocomplete
                     >
                     {collegeArray_edu.map((option) => (
                         <Select.Option key={option.value} value={option.label}>
                              {option.label}
                         </Select.Option>
                    ))}
                    </Select>
                      </Dropdown>

                  </div>
                  <div className="col-md-6 percentage-div">
                    <div className="col-md-5 per-col">
                        <label htmlFor="percentage">Percentage</label>
                        <Input type="number" 
                              id="percentage" 
                              name="percentage" 
                              value= {hobby.percentage}
                              onChange={(event) => handleEmploymentChange_edu(event, index, "percentage")}
                         />
                    </div>
                 
                    <div className="col-md-2 or-text">Or</div>
                    <div className="per-col col-md-5">
                           <label htmlFor="cgpa">CGPA</label>
                           <Input type="number" 
                                 id="cgpa" 
                                 name="cgpa" 
                                 value= {hobby.cgpa}
                                 onChange={(event) => handleEmploymentChange_edu(event, index, "cgpa")}
                           />
                    </div>
                
                  </div>
                  <div className="col-md-6 inputField">
                      <label htmlFor="year_of_complete">Select Year</label>
                           <DatePicker 
                              picker="year" 
                              placeholder="Select year"
                              id="year_of_complete" 
                              value= {hobby.year_of_complete ? moment(hobby.year_of_complete) : null} 
                              onChange={(event) => handleEmploymentChange_edu(event, index, "year_of_complete")}   
                            />
                  </div>
                  </div>
                </AccordionItemPanel>
              </AccordionItem>
            </Accordion>
         
          </div>
        ))}
           { employment_edu.length !== 0  && ( employment_edu[0].primary_qualification !== '' || employment_edu[0].secondary_qualification !== '' || employment_edu[0].specialization !== '' || employment_edu[0].college !== '' || employment_edu[0].percentage !== '' || employment_edu[0].cgpa !== '' || employment_edu[0].year_of_complete !== '' ) ?
               <Button type="primary" className="submit-btn">Save</Button>
               : ''
              }  
      {!showEmployment_edu && (
        <div className="add_education float-left">
          <button
            type="button"
            className="btn btn-default new-add"
            onClick={handleAddEmployment_edu}
          >
            + Add Employment
          </button>
        </div>
      )}
      {showEmployment_edu && (
        <>
          <div className="add_education float-left">
            <button
              type="button"
              className="btn btn-default new-add"
              onClick={handleAddEmployment_edu}
            >
              +  Add one more education
            </button>
          </div>

        </>
      )}
    </div>
  );
}

export default memo(EducationForm);
