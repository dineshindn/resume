import React, { useEffect, useRef } from 'react';
import Quill from 'quill';
import { useQuill } from 'react-quilljs';

function ExampleComponent() {
  const targetDivRef = useRef(null);
  const quillRef = useRef(null);

  const modules = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],
      [{ list: 'ordered' }, { list: 'bullet' }],
      ['link'],
    ],
  };

  const { quill, quillRef: qRef } = useQuill({ modules });

  useEffect(() => {
    if (quillRef.current) {
      const quill = new Quill(quillRef.current, {});
      quill.on('text-change', () => {
        const text = quill.getText();
        targetDivRef.current.textContent = text;
      });
    }
  }, [quillRef]);

  return (
    <div className='row col-md-12'>
      <h2 className='resume-title'>Professional Summary</h2>
      <div className='summary' style={{ height: 300 }}>
        <div ref={qRef} />
      </div>
      <div ref={targetDivRef} />
    </div>
  );
}

export default ExampleComponent;
