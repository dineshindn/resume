import React, { useState, useEffect } from "react";
import { Button, Space } from 'antd';
import { memo } from "react";
import axios from 'axios';
import "./project.css";
import {
  Accordion,
  AccordionItem,
  AccordionItemHeading,
  AccordionItemButton,
  AccordionItemPanel,
} from "react-accessible-accordion";
import "react-accessible-accordion/dist/fancy-example.css";
import { useQuill } from 'react-quilljs';
import 'quill/dist/quill.snow.css';
import ReactQuill from "react-quill";
import DOMPurify from 'isomorphic-dompurify';
import "react-quill/dist/quill.snow.css";
import { Select } from 'antd';
import { Input } from 'antd';
import { DatePicker } from 'antd';
const { TextArea } = Input;





const baseURL = "http://localhost:3001";

const year_options = [];
for (let year = 2023; year >= 1950; year--) {
  year_options.push({
    value:  year,
    label:  year,
  })

}

const Project_options = [
  {
    value:  'College',
    label:  'College',
  },
  {
    value:  'Company',
    label:  'Company',
  },
  {
    value:  'Training Institute',
    label:  'Training Institute',
  },
  {
    value:  'Corporate',
    label:  'Corporate',
  },
  {
    value:  'Freelancer',
    label:  'Freelancer',
  },
  {
    value:  'Cap stone',
    label:  'Cap stone',
  },
]

const modules = {
  toolbar: [
    ['bold', 'italic', 'underline'],
    [{'list': 'ordered'}, {'list': 'bullet'}],
    ['link'],
  ],
  clipboard: {
    matchVisual: false,
  },
};

function ProjectForm({ detail }) {

  console.log("hello certi 8")
  const [isChecked_pro, setIschecked_pro] = useState(false);
  const [showEmployment_pro, setShowEmployment_pro] = useState(-1); // initialize state with -1
  const [employment_pro, setEmployment_pro] = useState([]);
  const [userInfo_pro, setuserInfo_pro] = useState({
    title: "",
    description: "",
    information: "",
  });

  useEffect(() => {
    const fetchData = async () => {
      try{

  
    let getData = await axios.get(`${baseURL}/api/v1/profileupdate/103`);
    if(getData.data.data.projects){
      let exp_array = getData.data.data.projects;
      let employment_array = []
      console.log(exp_array, "course_array")
      exp_array.map((obj, index) => {  
        let exp_obj = {
          project_name: obj.project_name,
          project_for: obj.project_for,
          project_complete_yr: obj.project_complete_yr,
          project_summary: obj.project_summary
        };
         employment_array.push(exp_obj)
      })
      setEmployment_pro(employment_array)
     
   }
  }

catch(e){

}
   }

  fetchData();
}, []); 
  const handleCheckboxChange_pro = () => {
    setIschecked_pro(!isChecked_pro);
  }
  const handleAddEmployment_pro = () => {
    setShowEmployment_pro(-1); // reset state when adding a new item
    setEmployment_pro([
      ...employment_pro,
      {
        project_name: "",
        project_for: "",
        project_complete_yr: "",
        project_summary: ""
      },
    ]);
  };
  const handleDeleteHobby_pro = (index) => {
    const newEmployment_pro = [...employment_pro];
    newEmployment_pro.splice(index, 1);
    setEmployment_pro(newEmployment_pro);

  };
  const handleToggleAccordion_pro = (index) => {
    if (showEmployment_pro === index) {
      setShowEmployment_pro(-1); // toggle off if same item is clicked again
    } else {
      setShowEmployment_pro(index);
    }
  };
  const handleEmployementChange_pro = (event, index, field) => {
    var summary_value;
    if(field === 'job_description' || field === 'job_summary'){
      const newDescription = {...userInfo_pro};
      newDescription.description = event;
      setuserInfo_pro({ ...userInfo_pro, description: event });
      const sanitizedHtml = DOMPurify.sanitize( newDescription.description)
      const formattedText = <div dangerouslySetInnerHTML={{__html: sanitizedHtml}}></div>;
      summary_value = formattedText
    } 
    else if(field === 'project_for' || field === 'job_select_year'){
      summary_value = event
    }
    else{
      summary_value = event.target.value
    }
    const newEmployment = [...employment_pro];
    newEmployment[index][field] = summary_value;
    setEmployment_pro(newEmployment);
    // detail(employment)
  };

  const handleSubmit_pro = (event) => {
    event.preventDefault();
  };


  return (
    <div onSubmit={handleSubmit_pro} className="employment">
      <div className="row col-md-12 " >
        <h2 className="resume-title">Project Details</h2>
      </div>
      {employment_pro.map((hobby, index) => (
        <div key={index}>
          <Accordion allowZeroExpanded={true}>
            <AccordionItem>
              <AccordionItemHeading>
                <AccordionItemButton onClick={() => handleToggleAccordion_pro(index)}>
                  Project title {index + 1}{" "}
                  <button
                    type="button"
                    className="btn btn-default float-right "
                    onClick={() => handleDeleteHobby_pro(index)}
                  >
                    <i className="fa fa-trash"></i>
                  </button>
                </AccordionItemButton>
              </AccordionItemHeading>
              <AccordionItemPanel>
                <div className="row row_employment col-md-12">
                  <div className="col-md-6  inputField">
                    <label htmlFor="project_name">Project Name</label>
                    <Input type="text"
                    placeholder="Enter Project Name" 
                    id="project_name" 
                    name="project_name" 
                    value= {hobby.project_name}
                    onChange={(event) => handleEmployementChange_pro(event, index, "project_name")}
                    />
                  </div>
                  <div className="col-md-6 inputField">
                    <label htmlFor="project_for">Project For</label>
                  <Select
                    showSearch
                    placeholder="--Select--"
                    id= "project_for"
                    value= {hobby.project_for}
                    onChange={(event) => handleEmployementChange_pro(event, index, "project_for")}
                    options={ Project_options }
                    autoComplete= 'off'
                   />
                  </div>
                 
                  <div className="col-md-6 inputField">
                      <label htmlFor="job_select_year">Select Year</label>
                        <Select
                              showSearch
                              placeholder="Select year"
                              id="job_start_date" 
                              value= {hobby.job_select_year} 
                              onChange={(event) => handleEmployementChange_pro(event, index, "job_select_year")}  
                              options={year_options}
                         /> 
                  </div>
                  </div>
                  <div className="row row_employment col-md-12">
                       <div className="col-md-12 inputField">
                           <label htmlFor="technology">Project Summary</label>
                                <TextArea type="text" 
                                      id="project_summary" 
                                      name="project_summary" 
                                      value= {hobby.project_summary}
                                      onChange={(event) => handleEmployementChange_pro(event, index, "project_summary")}
                                /> 
                        </div>
                  </div> 
                </AccordionItemPanel>
              </AccordionItem>
            </Accordion>
          </div>
        ))}

        { employment_pro.length !== 0  && ( employment_pro[0].project_name !== '' || employment_pro[0].project_for !== '' || employment_pro[0].project_complete_yr !== '' || employment_pro[0].project_summary !== '') ?
               <Button type="primary" className="submit-btn">Save</Button>
               : ''
              }  
      {!showEmployment_pro && (
        <div className="add_education float-left">
          <button
            type="button"
            className="btn btn-default new-add"
            onClick={handleAddEmployment_pro}
          >
            + Add Course
          </button>
        </div>
      )}
      {showEmployment_pro && (
        <>
          

          <div className="add_education float-left">
            <button
              type="button"
              className="btn btn-default new-add"
              onClick={handleAddEmployment_pro}
            >
              +  Add one more Project
            </button>
          </div>

        </>
      )}
    </div>
  );
}

export default memo(ProjectForm);
