import React, { useState } from "react";
import "./check.css";
function HobbyForm() {
  const [showHobbies, setShowHobbies] = useState(false);
  const [hobbies, setHobbies] = useState([]);

  const handleAddHobby = () => {
    setShowHobbies(true);
    setHobbies([
      ...hobbies,
      {
        name: "",
        time: "",
        noOfPlayers: "",
        description: "",
      },
    ]);
  };

  const handleDeleteHobby = (index) => {
    const newHobbies = [...hobbies];
    newHobbies.splice(index, 1);
    setHobbies(newHobbies);
  };

  const handleHobbyChange = (event, index, field) => {
    const newHobbies = [...hobbies];
    newHobbies[index][field] = event.target.value;
    setHobbies(newHobbies);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(hobbies);
  };

  return (

    
    <div onSubmit={handleSubmit} className="education">
      <div className='row col-md-12'>
        <h2 className='resume-title'>Education</h2>
        <p className="sub-title">A varied education on your resume sums up the value that your learnings and background will bring to job.</p>
      </div>

      {showHobbies ?
        hobbies.map((hobby, index) => (
          <div key={index}>
            <label>
              Hobby #{index + 1}:
              <input
                type="text"
                value={hobby.name}
                onChange={(event) => handleHobbyChange(event, index, "name")}
                placeholder="Name"
              />
            </label>
            <label>
              Time:
              <input
                type="text"
                value={hobby.time}
                onChange={(event) => handleHobbyChange(event, index, "time")}
                placeholder="Time"
              />
            </label>
            <label>
              No of Players:
              <input
                type="text"
                value={hobby.noOfPlayers}
                onChange={(event) =>
                  handleHobbyChange(event, index, "noOfPlayers")
                }
                placeholder="No of Players"
              />
            </label>
            <label>
              Description:
              <textarea
                value={hobby.description}
                onChange={(event) =>
                  handleHobbyChange(event, index, "description")
                }
                placeholder="Description"
              />
            </label>
            <button type="button" onClick={() => handleDeleteHobby(index)}>
              Delete
            </button>
          </div>
        )) : ""}
      {!showHobbies && (
        <div className="add_education">
          <button type="button" onClick={handleAddHobby}>
            Add Education
          </button>
        </div>
        
      )}
      {showHobbies && (
        <>
          <button type="button" onClick={handleAddHobby}>
            Add Hobbys
          </button>
          <button type="submit">Submit</button>
        </>
      )}
    </div>
  );
}

export default HobbyForm;
