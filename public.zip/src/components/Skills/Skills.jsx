import React, {useEffect, useState} from 'react';
import { Select } from 'antd';
import { memo } from 'react';
import { Button, Space } from 'antd';
import axios from 'axios';

const baseURL = "http://localhost:3001";

function Skills() {
  console.log("hello certi 9")
  const [vendorArray_skill, setVendorArray_skill] = useState([]);
  const [skills_skill, setSkills_skill] = useState([])
  useEffect(() => {
    // Function to make the API call
    const fetchData = async () => {
      try {
        let vendorTArray_skill = []
        let getData = await axios.get(`${baseURL}/api/v1/profileupdate/103`);
        if(getData.data.data.skills){
          let exp_array = getData.data.data.skills;
          let employment_array = []
          console.log(exp_array, "course_array")
          exp_array.map((obj, index) => {  
             employment_array.push(obj.english)
          })
          setSkills_skill(employment_array)    
       }
        const response_skill = await axios.get(`${baseURL}/api/v1/skills`)
        console.log(response_skill.data.data, "vend res")
        for (let i=0; i<response_skill.data.data.length; i++){
          let vendorList =  {
            value: response_skill.data.data[i].id,
            label: response_skill.data.data[i].english,
          }
          vendorTArray_skill.push(vendorList)
        }
        setVendorArray_skill(vendorTArray_skill)

      } catch (error) {
        // Handle any errors
      }
    };

    // Call the API when the component is mounted
    fetchData();
  }, []); 

  const handleSkillsChange_skill= (e) => {
    setSkills_skill(e)
}

  return (
    <div className="job-skills">
       <div className="row col-md-12 " >
        <div className='col-md-12'>
        <h2 className="resume-title">Skills</h2>
           <Select
                
                mode="tags"
                style={{
                     width: '100%',
                }}
                value={skills_skill}
                onChange={handleSkillsChange_skill}
                placeholder="Search for Skills"
                options={vendorArray_skill}
          />
        </div>   
        { skills_skill.length !== 0 ?
               <Button type="primary" className="submit-btn">Save</Button>
               : ''
              }   
       </div>
     
          
    </div>
  )
}

export default memo(Skills)