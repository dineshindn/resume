import React, { useState } from "react";
import ReactQuill from "react-quill";
import DOMPurify from 'isomorphic-dompurify';
import "react-quill/dist/quill.snow.css";
const modules = {
  toolbar: [
    ['bold', 'italic', 'underline'],
    [{'list': 'ordered'}, {'list': 'bullet'}],
    ['link'],
  ],
  clipboard: {
    matchVisual: false,
  },
};

function Quillcheck() {
  const [userInfo, setuserInfo] = useState({
    title: "",
    description: "",
    information: "",
  });

  const ondescription = (value) => {
    setuserInfo({ ...userInfo, description: value });
  };

  const sanitizedHtml = DOMPurify.sanitize(userInfo.description);
  const formattedText = <div dangerouslySetInnerHTML={{__html: sanitizedHtml}}></div>;

   return (
    <div>
      <ReactQuill
        theme="snow"
        value={userInfo.description}
        onChange={ondescription}
        placeholder={"Write something awesome..."}
        modules={modules} // add the modules prop
      />
      {formattedText}
    </div>
  );
}

export default Quillcheck;
