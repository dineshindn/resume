import React, { useState, useEffect } from "react";
import { memo } from "react";
import moment from 'moment';
import "./course.css";
import {
  Accordion,
  AccordionItem,
  AccordionItemHeading,
  AccordionItemButton,
  AccordionItemPanel,
} from "react-accessible-accordion";
import "react-accessible-accordion/dist/fancy-example.css";
import { useQuill } from 'react-quilljs';
import 'quill/dist/quill.snow.css';
import ReactQuill from "react-quill";
import DOMPurify from 'isomorphic-dompurify';
import "react-quill/dist/quill.snow.css";
import axios from 'axios';
import { Select, Dropdown, Menu } from 'antd';
import { Button, Space } from 'antd';
import { Input } from 'antd';
import { DatePicker } from 'antd';
const { TextArea } = Input;


const baseURL = "http://localhost:3001";
const year_options = [];
for (let year = 2023; year >= 1950; year--) {
  year_options.push({
    value:  year,
    label:  year,
  })

}

const Vendor_options = [
  {
    value:  'CTS',
    label:  'CTS',
  },
  {
    value:  'TCS',
    label:  'TCS',
  },
  {
    value:  'GTalent',
    label:  'GTalent',
  },
  {
    value:  'RAVSoft',
    label:  'RAVSoft',
  },
  {
    value:  'Wipro',
    label:  'Wipro',
  },
]

const modules = {
  toolbar: [
    ['bold', 'italic', 'underline'],
    [{'list': 'ordered'}, {'list': 'bullet'}],
    ['link'],
  ],
  clipboard: {
    matchVisual: false,
  },
};

function CourseForm({ detail }) {

  console.log("hello certi 2")
  const [selectedVendorItem_course, setSelectedVendorItem_course] = useState(null);
  const [showVendorMessage_course, setShowVendorMessage_course] = useState(false);
  const [selectedTechnologyItem_course, setSelectedTechnologyItem_course] = useState(null);
  const [showTechnologyMessage_course, setShowTechnologyMessage_course] = useState(false);
  const [isChecked_course, setIschecked_course] = useState(false);
  const [showEmployment_course, setShowEmployment_course] = useState(-1); // initialize state with -1
  const [employment_course, setEmployment_course] = useState([]);
  const [vendorArray_course, setVendorArray_course] = useState([]);
  const [technologyArray_course, setTechnologyArray_course] = useState([]);
  const [userInfo_course, setuserInfo_course] = useState({
    title: "",
    description: "",
    information: "",
  });

  useEffect(() => {
    // Function to make the API call
    const fetchData = async () => {
      try {
        let vendorTArray_course = []
        let technologyTArray_course = []
        let getData = await axios.get(`${baseURL}/api/v1/profileupdate/103`);
        if(getData.data.data.courses){
          let exp_array = getData.data.data.courses;
          let employment_array = []
          console.log(exp_array, "course_array")
          exp_array.map((obj, index) => {  
              console.log(obj.course_complete_yr, "obj.course_complete_yr")
            let exp_obj = {
              course_name: obj.course_name,
              course_complete_yr: obj.course_complete_yr ? obj.course_complete_yr : null,
              course_duration: obj.course_duration,
              course_technology: obj.course_technology,
              course_vendor: obj.course_vendor,   
            };
             employment_array.push(exp_obj)
          })
          setEmployment_course(employment_array)
       }
        const response_course = await axios.get(`${baseURL}/api/v1/vendors`)
        console.log(response_course.data.data, "vend res")
        for (let i=0; i<response_course.data.data.length; i++){
          let vendorList =  {
            value: response_course.data.data[i].id,
            label: response_course.data.data[i].english,
          }
          vendorTArray_course.push(vendorList)
        }
        setVendorArray_course(vendorTArray_course)
        const spe_response_course = await axios.get(`${baseURL}/api/v1/course_technology`);
        console.log(spe_response_course.data.data, "tech res")
        for (let i=0; i<spe_response_course.data.data.length; i++){
          let technologyList =  {
            value: spe_response_course.data.data[i].id,
            label: spe_response_course.data.data[i].english,
          }
          technologyTArray_course.push(technologyList)
        }
        setTechnologyArray_course(technologyTArray_course)
      
        // Process the data or update the state
      } catch (error) {
        // Handle any errors
      }
    };

    // Call the API when the component is mounted
    fetchData();
  }, []); 

  const handleVendorChange_course = (value) => {
    setSelectedVendorItem_course(value[0]);
    setShowVendorMessage_course(false);
  };

  const handleVendorDropdownVisibleChange_course = (visible) => {
    if (visible && selectedVendorItem_course) {
      setShowVendorMessage_course(true);
    }
  };

  const renderVendorMenu_course = () => {
    if (showVendorMessage_course) {
      return (
        <Menu>
          <Menu.Item key="1" disabled>
               You can select only one item
          </Menu.Item>
        </Menu>
      );
    }
    return null;
  };

  const handleTechnologyChange_course_course = (value) => {
    setSelectedTechnologyItem_course(value[0]);
    setShowTechnologyMessage_course(false);
  };

  const handleTechnologyDropdownVisibleChange_course = (visible) => {
    if (visible && selectedTechnologyItem_course) {
      setShowTechnologyMessage_course(true);
    }
  };

  const renderTechnologyMenu_course = () => {
    if (showTechnologyMessage_course) {
      return (
        <Menu>
          <Menu.Item key="1" disabled>
               You can select only one item
          </Menu.Item>
        </Menu>
      );
    }
    return null;
  };
  const handleCheckboxChange_course = () => {
    setIschecked_course(!isChecked_course);
  }
  const handleAddEmployment_course = () => {
    setShowEmployment_course(-1); // reset state when adding a new item
    setEmployment_course([
      ...employment_course,
      {
        course_name: "",
        course_vendor: "",
        course_technology: "",
        course_complete_yr: null,
        course_duration: ""
      },
    ]);
  };

 

  const handleDeleteHobby_course = (index) => {
    const newEmployment = [...employment_course];
    newEmployment.splice(index, 1);
    setEmployment_course(newEmployment);
    // detail(newEmployment, "updateArray");
    
  };
  

  const handleToggleAccordion_course = (index) => {
    if (showEmployment_course === index) {
      setShowEmployment_course(-1); // toggle off if same item is clicked again
    } else {
      setShowEmployment_course(index);
    }
  };
  const handleEmploymentChange_course = (event, index, field) => {
    var summary_value;
    if(field === 'job_description' || field === 'job_summary'){
      const newDescription = {...userInfo_course};
      newDescription.description = event;
      setuserInfo_course({ ...userInfo_course, description: event });
      const sanitizedHtml = DOMPurify.sanitize( newDescription.description)
      const formattedText = <div dangerouslySetInnerHTML={{__html: sanitizedHtml}}></div>;
      summary_value = formattedText
    } 
    else if(field === 'course_complete_yr' || field === 'course_vendor' || field === 'course_technology'){
      summary_value = event
    }
    else{
      summary_value = event.target.value
    }
    const newEmployment = [...employment_course];
    newEmployment[index][field] = summary_value;
    setEmployment_course(newEmployment);
   
  };

  const handleSubmit_course = (event) => {
    event.preventDefault();
  };


  return (
    <div onSubmit={handleSubmit_course} className="employment">
      <div className="row col-md-12 " >
        <h2 className="resume-title">Course Details</h2>
      </div>
      {employment_course.map((hobby, index) => (
        <div key={index}>
          <Accordion allowZeroExpanded={true}>
            <AccordionItem>
              <AccordionItemHeading>
                <AccordionItemButton onClick={() => handleToggleAccordion_course(index)}>
                  Course title {index + 1}{" "}
                  <button
                    type="button"
                    className="btn btn-default float-right "
                    onClick={() => handleDeleteHobby_course(index)}
                  >
                    <i className="fa fa-trash"></i>
                  </button>
                </AccordionItemButton>
              </AccordionItemHeading>
              <AccordionItemPanel>
                <div className="row row_employment col-md-12">
                  <div className="col-md-6  inputField">
                    <label htmlFor="course_name">Course Name</label>
                    <Input type="text" 
                    id="course_name" 
                    name="course_name" 
                    placeholder="Enter Course Name"
                    value= {hobby.course_name}
                    onChange={(event) => handleEmploymentChange_course(event, index, "course_name")}
                    />
                  </div>
                  <div className="col-md-6 inputField">
                    <label htmlFor="vendor">Vendor</label>
                    {/* <Input type="text" 
                    id="vendor" 
                    name="vendor" 
                    value= {employment.vendor}
                    onChange={(event) => handleEmployementChange(event, index, "vendor")}
                    /> */}
                       <Dropdown
                           overlay={renderVendorMenu_course}
                           visible={showVendorMessage_course}
                           onVisibleChange={handleVendorDropdownVisibleChange_course}
                       >
                     <Select
                            mode="tags"
                            style={{ width: '100%' }}
                            placeholder="Search for a Company"
                            //onChange={handleVendorChange}
                            onChange={(event) => handleEmploymentChange_course(event, index, "course_vendor")}
                            value={hobby.course_vendor}
                            showSearch // Enable searching
                            autoComplete="off" // Disable autocomplete
                     >
                     {vendorArray_course.map((option) => (
                         <Select.Option key={option.value} value={option.value}>
                              {option.label}
                         </Select.Option>
                    ))}
                    </Select>
                      </Dropdown>
                  </div>
                 
                  <div className="col-md-6 inputField">
                    <label htmlFor="technology">Technology</label>
                    {/* <Input type="text" 
                    id="technology" 
                    name="technology" 
                    value= {employment.technology}
                    onChange={(event) => handleEmployementChange(event, index, "technology")}
                    /> */}
                    
                    <Dropdown
                           overlay={renderTechnologyMenu_course}
                           visible={showTechnologyMessage_course}
                           onVisibleChange={handleTechnologyDropdownVisibleChange_course}
                       >
                     <Select
                            mode="tags"
                            style={{ width: '100%' }}
                            placeholder="Search for a Technology"
                            onChange={(event) => handleEmploymentChange_course(event, index, "course_technology")}
                            value={hobby.course_technology}
                            showSearch // Enable searching
                            autoComplete="off" // Disable autocomplete
                     >
                     {technologyArray_course.map((option) => (
                         <Select.Option key={option.value} value={option.value}>
                              {option.label}
                         </Select.Option>
                    ))}
                    </Select>
                    </Dropdown>

                  </div>
                  <div className="col-md-6 inputField">
                      <label htmlFor="job_select_year">Select Year</label>    
                            <DatePicker 
                                  picker="year" 
                                  placeholder="Select year"
                                  id="course_complete_yr" 
                                  value={hobby.course_complete_yr ? moment(hobby.course_complete_yr) : null}
                                  onChange={(event) => handleEmploymentChange_course(event, index, "course_complete_yr")}   
                               />
                  </div>
                  <div className="col-md-6 inputField">
                    <label htmlFor="course_duration">Course Duration </label>
                    <Input type="number" 
                    id="course_duration" 
                    name="course_duration" 
                    placeholder="In days"
                    value= {hobby.course_duration}
                    onChange={(event) => handleEmploymentChange_course(event, index, "course_duration")}
                    />
                  </div>
                  </div>
                </AccordionItemPanel>
              </AccordionItem>
            </Accordion>
          </div>
        ))}

        { employment_course.length !== 0  && ( employment_course[0].course_name !== '' || employment_course[0].course_complete_yr !== '' || employment_course[0].course_duration !== '' || employment_course[0].course_technology !== '' || employment_course[0].course_vendor !== '') ?
               <Button type="primary" className="submit-btn" >Save</Button>
               : ''
              }  
      {!showEmployment_course && (
        <div className="add_education float-left">
          <button
            type="button"
            className="btn btn-default new-add"
            onClick={handleAddEmployment_course}
          >
            + Add Course
          </button>
        </div>
      )}
      {showEmployment_course && (
        <>
          <div className="add_education float-left">
            <button
              type="button"
              className="btn btn-default new-add"
              onClick={handleAddEmployment_course}
            >
              +  Add one more Course
            </button>
          </div>

        </>
      )}
    </div>
  );
}

export default memo(CourseForm);
