import React, { useState, useEffect } from "react";
import { memo } from "react";
import { Button, Space } from 'antd';
import "./certification.css";
import {
  Accordion,
  AccordionItem,
  AccordionItemHeading,
  AccordionItemButton,
  AccordionItemPanel,
} from "react-accessible-accordion";
import "react-accessible-accordion/dist/fancy-example.css";
import { useQuill } from 'react-quilljs';
import 'quill/dist/quill.snow.css';
import ReactQuill from "react-quill";
import DOMPurify from 'isomorphic-dompurify';
import "react-quill/dist/quill.snow.css";
import axios from 'axios';
import { Select, Dropdown, Menu } from 'antd';
import { Input } from 'antd';
import { DatePicker } from 'antd';
const { TextArea } = Input;
const baseURL = "http://localhost:3001";
const year_options = [];
for (let year = 2023; year >= 1950; year--) {
  year_options.push({
    value:  year,
    label:  year,
  })

}




const modules = {
  toolbar: [
    ['bold', 'italic', 'underline'],
    [{'list': 'ordered'}, {'list': 'bullet'}],
    ['link'],
  ],
  clipboard: {
    matchVisual: false,
  },
};

function CertificationForm({ detail }) {

  console.log("hello certi 1")
  const [selectedVendorItem_certi, setSelectedVendorItem_certi] = useState(null);
  const [showVendorMessage_certi, setShowVendorMessage_certi] = useState(false);
  const [selectedTechnologyItem_certi, setSelectedTechnologyItem_certi] = useState(null);
  const [showTechnologyMessage_certi, setShowTechnologyMessage_certi] = useState(false);
  const [isChecked_certi, setIschecked_certi] = useState(false);
  const [showEmployment_certi, setShowEmployment_certi] = useState(-1); // initialize state with -1
  const [employment_certi, setEmployment_certi] = useState([]);
  const [vendorArray_certi, setVendorArray_certi] = useState([]);
  const [technologyArray_certi, setTechnologyArray_certi] = useState([]);
  const [userInfo_certi, setuserInfo_certi] = useState({
    title: "",
    description: "",
    information: "",
  });

  useEffect(() => {
    // Function to make the API call
    const fetchData = async () => {
      try {
        let vendorTArray_certi = []
        let technologyTArray_certi = []
        let getData= await axios.get(`${baseURL}/api/v1/profileupdate/103`);
        if(getData.data.data.certification){
          let exp_array = getData.data.data.certification;
          let employment_array = []
          console.log(exp_array, "exp_array")
          exp_array.map((obj, index) => {    
            let exp_obj = {
              certificate_complete_yr : obj.certificate_complete_yr,
              certificate_name : obj.certificate_name,
              certificate_technology : obj.certificate_technology,
              certificate_vendor : obj.certificate_vendor,
             }
             employment_array.push(exp_obj)
          })
          setEmployment_certi(employment_array)
       }
        const response_certi = await axios.get(`${baseURL}/api/v1/vendors`)
        console.log(response_certi.data.data, "vend res")
        for (let i=0; i<response_certi.data.data.length; i++){
          let vendorList =  {
            value: response_certi.data.data[i].id,
            label: response_certi.data.data[i].english,
          }
          vendorTArray_certi.push(vendorList)
        }
        setVendorArray_certi(vendorTArray_certi)
        const spe_response_certi = await axios.get(`${baseURL}/api/v1/course_technology`);
        console.log(spe_response_certi.data.data, "tech res")
        for (let i=0; i<spe_response_certi.data.data.length; i++){
          let technologyList =  {
            value: spe_response_certi.data.data[i].id,
            label: spe_response_certi.data.data[i].english,
          }
          technologyTArray_certi.push(technologyList)
        }
        setTechnologyArray_certi(technologyTArray_certi)
      } catch (error) {
        // Handle any errors
      }
    };

    // Call the API when the component is mounted
    fetchData();
  }, []); 

  const handleVendorChange_certi = (value) => {
    setSelectedVendorItem_certi(value[0]);
    setShowVendorMessage_certi(false);
  };

  const handleVendorDropdownVisibleChange_certi = (visible) => {
    if (visible && selectedVendorItem_certi) {
      setShowVendorMessage_certi(true);
    }
  };

  const renderVendorMenu_certi = () => {
    if (showVendorMessage_certi) {
      return (
        <Menu>
          <Menu.Item key="1" disabled>
               You can select only one item
          </Menu.Item>
        </Menu>
      );
    }
    return null;
  };

  const handleTechnologyChange_certi = (value) => {
    setSelectedTechnologyItem_certi(value[0]);
    setShowTechnologyMessage_certi(false);
  };

  const handleTechnologyDropdownVisibleChange_certi = (visible) => {
    if (visible && selectedTechnologyItem_certi) {
      setShowTechnologyMessage_certi(true);
    }
  };

  const renderTechnologyMenu_certi = () => {
    if (showTechnologyMessage_certi) {
      return (
        <Menu>
          <Menu.Item key="1" disabled>
               You can select only one item
          </Menu.Item>
        </Menu>
      );
    }
    return null;
  };

  const handleAddEmployment_certi = () => {
    setShowEmployment_certi(-1); // reset state when adding a new item
    setEmployment_certi([
      ...employment_certi,
      {
        certificate_name: "",
        certificate_vendor: "",
        certificate_technology: "",
        certificate_complete_yr: ""
      },
    ]);
  };

  const handleDeleteHobby_certi = (index) => {
    const newEmployment = [...employment_certi];
    newEmployment.splice(index, 1);
    setEmployment_certi(newEmployment);
    detail(newEmployment, "updateArray");
  };
  
  const handleToggleAccordion_certi = (index) => {
    if (showEmployment_certi === index) {
      setShowEmployment_certi(-1); // toggle off if same item is clicked again
    } else {
      setShowEmployment_certi(index);
    }
  };
  const handleEmployementChange_certi = (event, index, field) => {
    var summary_value;
    if(field === 'job_description' || field === 'job_summary'){
      const newDescription = {...userInfo_certi};
      newDescription.description = event;
      setuserInfo_certi({ ...userInfo_certi, description: event });
      const sanitizedHtml = DOMPurify.sanitize( newDescription.description)
      const formattedText = <div dangerouslySetInnerHTML={{__html: sanitizedHtml}}></div>;
      summary_value = formattedText
    } 
    else if(field === 'certificate_complete_yr' || field === 'certificate_vendor' || field === 'certificate_technology') {
      summary_value = event
    }
  
    else{
      summary_value = event.target.value
    }
    const newEmployment = [...employment_certi];
    newEmployment[index][field] = summary_value;
    setEmployment_certi(newEmployment);
   // detail(employment)
  };

  const handleSubmit_certi = (event) => {
    event.preventDefault();
  };


  return (
    <div onSubmit={handleSubmit_certi} className="employment">
      <div className="row col-md-12 " >
        <h2 className="resume-title">Certifications Details</h2>
      </div>
      {employment_certi.map((hobby, index) => (
        <div key={index}>
          <Accordion allowZeroExpanded={true}>
            <AccordionItem>
              <AccordionItemHeading>
                <AccordionItemButton onClick={() => handleToggleAccordion_certi(index)}>
                  Certificate title {index + 1}{" "}
                  <button
                    type="button"
                    className="btn btn-default float-right "
                    onClick={() => handleDeleteHobby_certi(index)}
                  >
                    <i className="fa fa-trash"></i>
                  </button>
                </AccordionItemButton>
              </AccordionItemHeading>
              <AccordionItemPanel>
                <div className="row row_employment col-md-12">
                  <div className="col-md-6  inputField">
                    <label htmlFor="certificate_name">Certification Name</label>
                    <Input type="text" 
                    id="certificate_name" 
                    name="certificate_name" 
                    placeholder="Enter Course Name"
                    value= {hobby.certificate_name}
                    onChange={(event) => handleEmployementChange_certi(event, index, "certificate_name")}
                    />
                  </div>
                  <div className="col-md-6 inputField">
                    <label htmlFor="vendor">Vendor</label>
                      <Dropdown
                           overlay={renderVendorMenu_certi}
                           visible={showVendorMessage_certi}
                           onVisibleChange={handleVendorDropdownVisibleChange_certi}
                       >
                     <Select
                            mode="tags"
                            style={{ width: '100%' }}
                            placeholder="Search for a Company"
                            onChange={(event) => handleEmployementChange_certi(event, index, "certificate_vendor")}
                            value = {hobby.certificate_vendor}
                            showSearch // Enable searching
                            autoComplete="off" // Disable autocomplete
                     >
                     {vendorArray_certi.map((option) => (
                         <Select.Option key={option.value} value={option.value}>
                              {option.label}
                         </Select.Option>
                    ))}
                    </Select>
                      </Dropdown>
                  </div>
                 
                  <div className="col-md-6 inputField">
                    <label htmlFor="technology">Technology</label>
                    <Dropdown
                           overlay={renderTechnologyMenu_certi}
                           visible={showTechnologyMessage_certi}
                           onVisibleChange={handleTechnologyDropdownVisibleChange_certi}
                       >
                     <Select
                            mode="tags"
                            style={{ width: '100%' }}
                            placeholder="Search for a Technology"
                            onChange={(event) => handleEmployementChange_certi(event, index, "certificate_technology")}
                            value = {hobby.certificate_technology}
                            showSearch // Enable searching
                            autoComplete="off" // Disable autocomplete
                     >
                     {technologyArray_certi.map((option) => (
                         <Select.Option key={option.value} value={option.value}>
                              {option.label}
                         </Select.Option>
                    ))}
                    </Select>
                    </Dropdown>
                  </div>
                  <div className="col-md-6 inputField">
                      <label htmlFor="job_select_year">Select Year</label>
                          <Select
                              showSearch
                              placeholder="Select year"
                              id="job_start_date" 
                              value= {hobby.certificate_complete_yr} 
                              onChange={(event) => handleEmployementChange_certi(event, index, "certificate_complete_yr")}  
                              options={year_options}
                         />  
                          
                  </div>
                  </div>
                </AccordionItemPanel>
              </AccordionItem>
            </Accordion>
          </div>
        ))}
           { employment_certi.length !== 0  && ( employment_certi[0].certificate_complete_yr !== '' || employment_certi[0].certificate_name  !== '' || employment_certi[0].certificate_technology !== '' || employment_certi[0].certificate_vendor !== '') ?
               <Button type="primary" className="submit-btn" >Save</Button>
               : ''
              }  
      {!showEmployment_certi && (
        <div className="add_education float-left">
          <button
            type="button"
            className="btn btn-default new-add"
            onClick={handleAddEmployment_certi}
          >
            + Add Course
          </button>
        </div>
      )}
      {showEmployment_certi && (
        <>
          <div className="add_education float-left">
            <button
              type="button"
              className="btn btn-default new-add"
              onClick={handleAddEmployment_certi}
            >
              +  Add one more Certificate
            </button>
          </div>

        </>
      )}
    </div>
  );
}

export default memo(CertificationForm);
