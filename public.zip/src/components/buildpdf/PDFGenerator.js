import React, { useState } from 'react';
import { pdfjs, Document, Page } from 'react-pdf';
import samplePDF from '../../assets/PPRA.pdf'; // Replace this with your PDF file path
import pdfjsWorker from "pdfjs-dist/build/pdf.worker";
// Configure the worker path for pdf.js
pdfjs.GlobalWorkerOptions.workerSrc = '/pdf.worker.js'; // Replace with the correct local path to pdf.worker.js

const PDFViewer = () => {
  const [numPages, setNumPages] = useState(null);

  function onDocumentLoadSuccess({ numPages }) {
    setNumPages(numPages);
  }

  return (
    <div>
      <h1>PDF Viewer</h1>
      <div style={{ width: '100%', height: '600px' }}>
        <Document file={samplePDF} onLoadSuccess={onDocumentLoadSuccess}>
          {Array.from(new Array(numPages), (el, index) => (
            <Page key={`page_${index + 1}`} pageNumber={index + 1} width={600} />
          ))}
        </Document>
      </div>
    </div>
  );
};

export default PDFViewer;
