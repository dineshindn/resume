import React, {useState} from 'react'
import { Select, Dropdown, Menu } from 'antd';

const options = [
    {
      id: 1,
      value: 'Vidyaa Vikas',
      label: 'Vidyaa Vikas',
    },
    {
      id: 2,
      value: 'K.S.R College',
      label: 'K.S.R College',
    },
    {
      id: 3,
      value: 'P.S.G College',
      label: 'P.S.G College',
    },
    {
      id: 4,
      value: 'Valli College',
      label: 'Valli College',
    },
  ];
function Checkdd() {
    console.log(options, "optios 22222222222")
    const [selectedItem, setSelectedItem] = useState(null);
    const [showMessage, setShowMessage] = useState('');
  
    const handleChange = (value) => {
      console.log(value, "333333333333")
      setSelectedItem(value);

      
    };
    const handleClickChange = () => {
        console.log("333333444444444333333")
        setShowMessage("success");
    }
    const handleClickRemove = () => {
        console.log("333333444444444333333")
        setShowMessage("");
    }
  return (
    <div>
<Select
      mode="multiple"
      style={{
        width: '100%',
      }}
      value={selectedItem}
      placeholder="Please select"
      onChange={handleChange}
      options={options}
    />
  <p>{showMessage}</p>
       {/* {options.map((option) => (
          <Select.Option key={option.value} value={option.value}>
            {option.label}
          </Select.Option>
        ))} */}
    </div>
  )
}

export default Checkdd