import React, {useState, useEffect} from 'react';
import { Select } from 'antd';
import { Button, Space } from 'antd';
import axios from 'axios';
import { memo } from "react";

const baseURL = "http://localhost:3001";


function Hobbies({detail }) {

  console.log("hobbies")

  const [vendorArray_hob, setVendorArray_hob] = useState([]);
  const [hobbies_hob, setHobbies_hob] = useState([])
  useEffect(() => {
    // Function to make the API call
    const fetchData = async () => {
      try {
        let vendorTArray_hob = []
        let getData = await axios.get(`${baseURL}/api/v1/profileupdate/103`);
        if(getData.data.data.hobbies){
          let exp_array = getData.data.data.hobbies;
          let employment_array = []
          console.log(exp_array, "course_array")
          exp_array.map((obj, index) => {  
             employment_array.push(obj.english)
          })
          setHobbies_hob(employment_array)    
       }
        const response_hob = await axios.get(`${baseURL}/api/v1/hobbies`)
        console.log(response_hob.data.data, "vend res")
        for (let i=0; i<response_hob.data.data.length; i++){
          let vendorList =  {
            value: response_hob.data.data[i].id,
            label: response_hob.data.data[i].english,
          }
          vendorTArray_hob.push(vendorList)
        }
        setVendorArray_hob(vendorTArray_hob)
    
       
        // Process the data or update the state
      } catch (error) {
        // Handle any errors
      }
    };

    // Call the API when the component is mounted
    fetchData();
  }, []); 

  const handleHobbiesChange_hob = (e) => {
      setHobbies_hob(e)
  }

  return (
    <div className="job-skills">
       <div className="row col-md-12 " >
        <div className='col-md-12'>
        <h2 className="resume-title">Hobbies</h2>
           <Select
                mode="tags"
                style={{
                     width: '100%',
                }}
                value={hobbies_hob}
                onChange={handleHobbiesChange_hob}
                placeholder="Search for Hobbies"
                options={vendorArray_hob}
          />
        </div>   
        { hobbies_hob.length !== 0 ?
               <Button type="primary" className="submit-btn">Save</Button>
               : ''
              }  
       </div>
          
    </div>
  )
}

export default memo(Hobbies)

