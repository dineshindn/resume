import ReactHtmlParser from 'react-html-parser';
import { Text, View } from '@react-pdf/renderer';
import React from 'react';

export const htmlParser = (taskDescription) => {
  if (taskDescription) {
    const parsedHtml = ReactHtmlParser(taskDescription);
    return parsedHtml.map((element, index) => {
      const type = element.type;

      if (type === 'p') {
        return <Text key={index}>{element.props.children}</Text>;
      } else {
        return null;
      }
    });
  } else {
    return null;
  }
};

const MyComponent = () => {
  const parsedHtml = htmlParser('<p><strong><i>Hello world</i></strong></p>');

  return (
    <View>
      <Text>Description:</Text>
      {parsedHtml}
    </View>
  );
};

export default MyComponent;
