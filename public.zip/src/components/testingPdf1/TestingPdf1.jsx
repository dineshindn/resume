import { useRef } from "react";
import jsPDF from "jspdf";
import ReportTemplate from "./ReportTemplate";

function TestingPdf() {
  const reportTemplateRef = useRef(null);

  const handleGeneratePdf = () => {
    const doc = new jsPDF({
      orientation: 'l', // landscape
        unit: 'pt', // points, pixels won't work properly
        format: [297, 210]  
    });

    // Adding the fonts
    doc.setFont("Inter-Regular", "normal");

    doc.html(reportTemplateRef.current, {
      async callback(doc) {
        await doc.save("document");
      }
    });
  };

  return (
    <div>
      <button className="button" onClick={handleGeneratePdf}>
        Generate PDF
      </button>
      <div ref={reportTemplateRef}>
        <ReportTemplate />
      </div>
    </div>
  );
}

export default TestingPdf;
