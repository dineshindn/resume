import React, {useEffect, useState} from 'react';
import { Select } from 'antd';
import {memo} from 'react';
import { Button, Space } from 'antd';
import axios from 'axios';

const baseURL = "http://localhost:3001";

function Languages({detail }) {

  console.log("hello certi 7")
  const [vendorArray_lang, setVendorArray_lang,] = useState([]);
  const [languages_lang, setLanguages_lang,] = useState([])
  useEffect(() => {
    // Function to make the API call
    const fetchData = async () => {
      try {
        let vendorTArray_lang = []
        let getData = await axios.get(`${baseURL}/api/v1/profileupdate/103`);
        if(getData.data.data.languages){
          let exp_array = getData.data.data.languages;
          let employment_array = []
          console.log(exp_array, "course_array")
          exp_array.map((obj, index) => {  
             employment_array.push(obj.english)
          })
          setLanguages_lang(employment_array)
       }
        const response_lang = await axios.get(`${baseURL}/api/v1/language`)
        console.log(response_lang.data.data, "vend res")
        for (let i=0; i<response_lang.data.data.length; i++){
          let vendorList =  {
            value: response_lang.data.data[i].id,
            label: response_lang.data.data[i].english,
          }
          vendorTArray_lang.push(vendorList)
        }
        setVendorArray_lang(vendorTArray_lang)
      } catch (error) {
        // Handle any errors
      }
    };

    // Call the API when the component is mounted
    fetchData();
  }, []); 

  const handleLanguagesChange_lang = (e) => {
    setLanguages_lang(e)
}
  return (
    <div className="job-skills">
    <div className="row col-md-12 " >
     <div className='col-md-12'>
     <h2 className="resume-title">Languages</h2>
     <Select
      mode="multiple"
      allowClear
      style={{
        width: '100%',
      }}
      value={languages_lang}
      onChange={handleLanguagesChange_lang}
      placeholder="Search for Languages"
      options={vendorArray_lang}
    />
     </div>  
     { languages_lang.length !== 0 ?
               <Button type="primary" className="submit-btn">Save</Button>
               : ''
              } 
    </div>     
   </div>
   
  )
}

export default memo(Languages)