import { Select, Dropdown, Menu } from 'antd';
import { useState } from 'react';

const options = [
  {
    value: 'Vidyaa Vikas',
    label: 'Vidyaa Vikas',
  },
  {
    value: 'K.S.R College',
    label: 'K.S.R College',
  },
  {
    value: 'P.S.G College',
    label: 'P.S.G College',
  },
  {
    value: 'Valli College',
    label: 'Valli College',
  },
];

const SkillForm = () => {
  const [selectedItem, setSelectedItem] = useState(null);
  const [showMessage, setShowMessage] = useState(false);

  const handleChange = (value) => {
    setSelectedItem(value);
    setShowMessage(false);
  };

  const handleDropdownVisibleChange = (visible) => {
    if (visible && selectedItem) {
      setShowMessage(!showMessage);
    }
  };

  const handleOpenDropdown = () => {
    if (!selectedItem) {
      setShowMessage(false);
    }
  };

  const renderMenu = () => {
    if (showMessage) {
      return (
        <Menu>
          <Menu.Item key="1" disabled>
            You can select only one item
          </Menu.Item>
        </Menu>
      );
    }
    return null;
  };

  return (
    <Dropdown
      overlay={renderMenu}
      visible={showMessage}
      onVisibleChange={handleDropdownVisibleChange}
      onClick={handleOpenDropdown}
    >
      <Select
        mode="tags"
        style={{ width: '100%' }}
        placeholder="Tags Mode"
        onChange={handleChange}
        value={selectedItem}
        showSearch // Enable searching
        autoComplete="off" // Disable autocomplete
      >
        {options.map((option) => (
          <Select.Option key={option.value} value={option.value}>
            {option.label}
          </Select.Option>
        ))}
      </Select>
    </Dropdown>
  );
};

export default SkillForm;
