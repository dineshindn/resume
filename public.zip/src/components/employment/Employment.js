import React, { useState,  useEffect } from "react";
import "./employment.css";
import moment from 'moment';
import { memo } from "react";
import { Select, Dropdown, Menu } from 'antd';
import {
  Accordion,
  AccordionItem,
  AccordionItemHeading,
  AccordionItemButton,
  AccordionItemPanel,
} from "react-accessible-accordion";
import "react-accessible-accordion/dist/fancy-example.css";
import { useQuill } from 'react-quilljs';
import 'quill/dist/quill.snow.css';
import ReactQuill from "react-quill";
import DOMPurify from 'isomorphic-dompurify';
import "react-quill/dist/quill.snow.css";
import axios from 'axios';
import { Button, Space } from 'antd';
import { Input } from 'antd';
import { DatePicker } from 'antd';
const { TextArea } = Input;
const year_options = [];
for (let year = 2023; year >= 1950; year--) {
  year_options.push({
    value:  year,
    label:  year,
  })

}

const baseURL = "http://localhost:3001";

const employment_type_options = [
  {
    value: 'Permanant',
    label: 'Permanant',
  },
  {
    value: 'Contract',
    label: 'Contract',
  },
  {
    value: 'Freelance',
    label: 'Freelance',
  },
]


const month_options = [
  {
    value:  'January',
    label:  'January',
  },
  {
    value:  'February',
    label:  'February',
  },
  {
    value:  'March',
    label:  'March',
  },
  {
    value:  'April',
    label:  'April',
  },
  {
    value:  'May',
    label:  'May',
  },
  {
    value:  'June',
    label:  'June',
  },
  {
    value:  'July',
    label:  'July',
  },
  {
    value:  'August',
    label:  'August',
  },
  {
    value:  'September',
    label:  'September',
  },
  {
    value:  'October',
    label:  'October',
  },
  {
    value:  'November',
    label:  'November',
  },
  {
    value:  'December',
    label:  'December',
  },

]

const modules = {
  toolbar: [
    ['bold', 'italic', 'underline'],
    [{'list': 'ordered'}, {'list': 'bullet'}],
    ['link'],
  ],
  clipboard: {
    matchVisual: false,
  },
};
// const EmploymentForm = React.memo(({ detail, myEmployment}) => {
function EmploymentForm  ({ detail }) {

  console.log("hello certi 2")
  const [selectedCompanyItem, setSelectedCompanyItem] = useState(null);
  const [showCompanyMessage, setShowCompanyMessage] = useState(false);
  const [selectedDesignationItem, setSelectedDesignationItem] = useState(null);
  const [showDesignationMessage, setShowDesignationMessage] = useState(false);
  const [isChecked, setIschecked] = useState(false);
  const [showEmployment, setShowEmployment] = useState(-1); // initialize state with -1
  const [employment, setEmployment] = useState([]);
  const [companyArray, setCompanyArray] = useState([]);
  const [designationArray, setDesignationArray] = useState([]);
  const [userInfo, setuserInfo] = useState({
    title: "",
    description: "",
    information: "",
  });

 // console.log(myEmployment, employment, "myemp 22222222222222")
  useEffect(() => {
    // Function to make the API call
    const fetchData = async () => {
      try {
        let getData = await axios.get(`${baseURL}/api/v1/profileupdate/103`);
        if(getData.data.data.experience){
          let exp_array = getData.data.data.experience;
          let employment_array = []
          console.log(exp_array, "exp_array")
          exp_array.map((obj, index) => {    
            let exp_obj = {
               currently_working: obj.currentCompany,
               job_designation: obj.Designation,
               employment_type: obj.type,
               start_month: obj.start_month,
               start_year: obj.start_year,
               end_month: obj.end_month,
               end_year: obj.end_year,
               job_summary: obj.job_summary,
               job_accomplishments: obj.job_accomplishments,
             }
             employment_array.push(exp_obj)
          })
          setEmployment(employment_array)
          detail(employment_array, "getArray");
        //  setStates(employment_array)
          console.log(employment, "check exp at resumejs")
       }
   
      } catch (error) {
        // Handle any errors
      }
    };

    // Call the API when the component is mounted
    fetchData();
  }, [setEmployment]); 

  const handleSetCompany = async() => {
    let companyTArray = []
    const response = await axios.get(`${baseURL}/api/v1/current_company`)
    console.log(response.data.data, "res")
    for (let i=0; i<response.data.data.length; i++){
      let companyList =  {
        value: response.data.data[i].english,
        label: response.data.data[i].english,
      }
      companyTArray.push(companyList)
    }
    setCompanyArray(companyTArray)
    console.log(companyTArray, "array")
  }

  const handleSetDesignation = async() => {
  let designationTArray = []
  const des_response = await axios.get(`http://localhost:3001/api/v1/designation`)
  for (let i=0; i<des_response.data.data.length; i++){
    let designationList =  {
      value: des_response.data.data[i].english,
      label: des_response.data.data[i].english,
    }
    designationTArray.push(designationList)
  }
  setDesignationArray(designationTArray)
}

  const handleCompanyChange = (event, index, field) => {
    console.log(event, "11111value")
    setSelectedCompanyItem(event[0]);
    setShowCompanyMessage(false);
    handleEmployementChange(event, index, field)
  };
  const handleCompanyDropdownVisibleChange = (visible) => {
    console.log(visible, "222222value")
    if (visible && selectedCompanyItem) {
      setShowCompanyMessage(true);
    }
    
  };

  const renderCompanyMenu = () => {
    if (showCompanyMessage) {
      return (
        <Menu>
          <Menu.Item key="1" disabled>
               You can select only one item
          </Menu.Item>
        </Menu>
      );
    }
    return null;
  };


  const handleDesignationChange = (value) => {
    setSelectedDesignationItem(value[0]);
    setShowDesignationMessage(false);
  };

  const handleDesignationDropdownVisibleChange = (visible) => {
    if (visible && selectedDesignationItem) {
      setShowDesignationMessage(true);
    }
  };

  const renderDesignationMenu = () => {
    if (showDesignationMessage) {
      return (
        <Menu>
          <Menu.Item key="1" disabled>
               You can select only one item
          </Menu.Item>
        </Menu>
      );
    }
    return null;
  };
  const handleCheckboxChange = () => {
    setIschecked(!isChecked);
  }
  const handleAddEmployment = () => {
    setShowEmployment(-1); // reset state when adding a new item
    setEmployment([
      ...employment,
      {
        currently_working: "",
        job_designation: "",
        employment_type: "",
        start_month: "",
        start_year: "",
        end_month: "",
        end_year: "",
        job_summary: "",
        job_accomplishments: "",
      },
    ]);
  };

  const handleDeleteHobby = (index) => {
    const newEmployment = [...employment];
    newEmployment.splice(index, 1);
    setEmployment(newEmployment);
    detail(newEmployment, "updateArray");
  };
  

  const handleToggleAccordion = (index) => {
    if (showEmployment === index) {
      setShowEmployment(-1); // toggle off if same item is clicked again
    } else {
      setShowEmployment(index);
    }
  };

  const handleEmployementChange = (event, index, field) => {
    console.log(event, index, field, "event of employement")
    var summary_value;
    if(field === 'job_summary'){
      const newDescription = {...userInfo};
      newDescription.description = event;
      setuserInfo({ ...userInfo, description: event });
      const sanitizedHtml = DOMPurify.sanitize( newDescription.description)
      const formattedText = <div dangerouslySetInnerHTML={{__html: sanitizedHtml}}></div>;
      summary_value = formattedText
    } 
    else if(field === 'start_year' || field === 'start_month' || field === 'end_month' || field === 'end_year' || field === 'employment_type'){
      summary_value = event
    }
    else if(field === "currently_working"){
      console.log(event, "company evnt")
      setSelectedCompanyItem(event[0]);
      summary_value = event[0];
    }
    else if(field === "job_designation"){
      setSelectedDesignationItem(event[0])
      summary_value = event[0];
    }
    else{
      summary_value = event.target.value
    }
    const newEmployment = [...employment];
    newEmployment[index][field] = summary_value;
    setEmployment(newEmployment);
    //detail(newEmployment)
    console.log(newEmployment, "newEmployment")
  };

  const handleSubmit = (event) => {
    event.preventDefault();
  };
  const handleCompanyLeave = () => {
    setShowCompanyMessage(false);
  }

  const handleDesignationLeave = () => {
    setShowDesignationMessage(false);
  }
  
  const handleApiCall = () => {
    detail(employment, "updateArray")
  }

  return (
    <div onSubmit={handleSubmit} className="employment">
      <div className="row col-md-12 " >
        <h2 className="resume-title">Employment</h2>
        <p className="sub-title">
          A varied education on your resume sums up the value that your
          learnings and background will bring to job.
        </p>
      </div>

      {employment.map((hobby, index) => (
        <div key={index}>
          <Accordion allowZeroExpanded={true}>
            <AccordionItem>
              <AccordionItemHeading>
                <AccordionItemButton onClick={() => handleToggleAccordion(index)}>
                  Job titles {index + 1}{" "}
                  <button
                    type="button"
                    className="btn btn-default float-right "
                    onClick={() => handleDeleteHobby(index)}
                  >
                    <i className="fa fa-trash"></i>
                  </button>
                </AccordionItemButton>
              </AccordionItemHeading>
              <AccordionItemPanel>
                <div className="row row_employment col-md-12">
                  <div className="col-md-6  inputField">
                    <label htmlFor="job_company_name">Company Name</label>
                    {/* <Input type="text" 
                    id="job_employer" 
                    name="job_employer" 
                    value= {employment.job_employer}
                    onChange={(event) => handleEmployementChange(event, index, "job_employer")}
                    /> */}
                      <Dropdown
                         overlay={renderCompanyMenu}
                         visible={showCompanyMessage}
                         onVisibleChange={handleCompanyDropdownVisibleChange}
                       >
                     <Select
                            mode="tags"
                            style={{ width: '100%' }}
                            placeholder="Search for a Company"
                            id="currently_working"
                            onChange={  (event) => handleCompanyChange(event, index, "currently_working") }
                            onClick={handleSetCompany}
                            value={hobby.currently_working}
                            showSearch // Enable searching
                            autoComplete="off" // Disable autocomplete
                            onMouseLeave={handleCompanyLeave}
                     >
                     {companyArray.map((option) => (
                         <Select.Option key={option.value} value={option.label}>
                              {option.label}
                         </Select.Option>
                    ))}
                    </Select>
                      </Dropdown>
                  </div>
                  <div className="col-md-6 inputField">
                    <label htmlFor="job_designation">Designation</label>
                    {/* <Input type="text" 
                    id="job_title" 
                    name="job_title" 
                    value= {employment.job_title}
                    onChange={(event) => handleEmployementChange(event, index, "job_title")}
                    /> */}
                      <Dropdown
                           overlay={renderDesignationMenu}
                           visible={showDesignationMessage}
                           onVisibleChange={handleDesignationDropdownVisibleChange}
                       >
                     <Select
                            mode="tags"
                            style={{ width: '100%' }}
                            id="job_designation"
                            placeholder="Search for a Designation"
                            onClick = {handleSetDesignation}
                            onChange={ (event) => handleEmployementChange(event, index, "job_designation")}  
                            // value={selectedDesignationItem ? [selectedDesignationItem] : []}
                            value={hobby.job_designation}
                            showSearch // Enable searching
                            onMouseLeave = {handleDesignationLeave}
                            autoComplete = "off" // Disable autocomplete
                     >
                     {designationArray.map((option) => (
                         <Select.Option key={option.value} value={option.label}>
                              {option.label}
                         </Select.Option>
                    ))}
                    </Select>
                      </Dropdown>

                  </div>
                  <div className="col-md-6 inputField">
                    <label htmlFor="employment_type">Employment Type</label>
                    {/* <Input type="text" 
                    id="job_employment_type" 
                    name="job_employment_type" 
                    value= {employment.job_employment_type}
                    onChange={(event) => handleEmployementChange(event, index, "job_employment_type")}
                    /> */}
                      <Select
                    showSearch
                    placeholder="Select Employement Type"
                    value= {hobby.employment_type}
                    onChange={ (event) => handleEmployementChange(event, index, "employment_type")}
                    options={ employment_type_options }
                    autoComplete= 'off'
                   />   
                  </div>
                  </div>
                  <div className="col-md-12 check-additional">
                     <Input
                          id="checkbox-extend"
                          type="checkbox"
                          checked={isChecked}
                          onChange={handleCheckboxChange}
                     />
                       <label htmlFor="checkbox-extend"> I am currently working in this role</label>
                
                  </div>
   
                <div className="row row_employment col-md-12">
                   {/* <div className="col-md-6 inputField">
                    <label htmlFor="job_start_date">Start Date</label>
                    <input
                      type="month"
                      id="job_start_date"
                      name="job_start_date"
                      value= {employment.job_start_date}
                      onChange={(event) => handleEmployementChange(event, index, "job_start_date")}

                    />
                 

                    </div> */}
                  <div className="col-md-6 inputField">
                      <label htmlFor="job_start_date">Start Date</label>
                      <Select
                              showSearch
                              placeholder="Start date"
                              id="start_month" 
                             // value= {hobby.start_month} 
                              value= {hobby.start_month ? month_options[hobby.start_month - 1] : undefined} 
                              onChange={(event) => handleEmployementChange(event, index, "start_month")}
                              options={month_options}
                   />
                     
                    </div>
                    <div className="col-md-6 inputField">
                      <label htmlFor="job_select_year">Select Year</label>
                        {/* <select  value= {employment.job_select_year} onChange={(event) => handleEmployementChange(event, index, "job_select_year")}> */}
              

                            <DatePicker 
                              picker="year" 
                              placeholder="Select year"
                              id="start_year" 
                              value= {hobby.start_year ? moment(hobby.start_year) : null} 
                              onChange={(event) => handleEmployementChange(event, index, "start_year")}
                              // onChange={(event) => handleEmployementChange(event, index, "year_of_complete")}   
                            />
                         
                          {/* <option value="">-- Select --</option>
                             {renderYearOptions()}
                        </select> */}
                    </div>
                    </div>
                 {!isChecked &&    <div className="row row_employment col-md-12">
                    <div className="col-md-6 inputField">
                      <label htmlFor="job_end_date">End Date</label>
                      <Select
                              showSearch
                              placeholder="End date"
                              id="end_month" 
                              value= {hobby.end_month ? month_options[hobby.end_month - 1] : undefined} 
                              onChange={(event) => handleEmployementChange(event, index, "end_month")}   
                              options={month_options}
                       />
              
                    </div>
                    <div className="col-md-6 inputField">
                      <label htmlFor="job_select_endyear">Select Year</label>
                        {/* <Select
                              showSearch
                              placeholder="Select year"
                              id="end_year" 
                              value= {hobby.end_year} onChange={(event) => handleEmployementChange(event, index, "end_year")}  
                              options={year_options}
                        />   */}

                           <DatePicker 
                              picker="year" 
                              placeholder="Select year"
                              id="end_year" 
                              value= {hobby.end_year ? moment(hobby.end_year) : null} 
                              onChange={(event) => handleEmployementChange(event, index, "end_year")}
                              // onChange={(event) => handleEmployementChange(event, index, "year_of_complete")}   
                            />  
                      </div> 
                     </div>  
                    }
                    <div className="row row_employment col-md-12">        
                    {/* <div className="col-md-6 inputField">
                      <label htmlFor="job_end_date">End Date</label>
                      <input
                        type="month"
                        id="job_end_date"
                        name="job_end_date"
                        value= {employment.job_end_date}
                        onChange={(event) => handleEmployementChange(event, index, "job_end_date")}
  
                      />
                    </div> */}

                    {/* <div className="col-md-6 inputField">
                      <label htmlFor="job_summary">Job Summary</label>
                      <input type="text" 
                      id="job_summary" 
                      name="job_summary" 
                      value= {employment.job_summary}
                      onChange={(event) => handleEmployementChange(event, index, "job_summary")}

                      />
                    </div> */}
                     
                    <div className="col-md-12 inputField"> 
                    <p className="float-left job-summary">Job Summary</p>
                    </div>
                    <div className="col-md-12 inputField" style={{ height: 235 }}> 
                      <div className='summary' style={{ height: 200 }}>
                               <ReactQuill
                                    theme="snow"
                                    //value={userInfo.description}
                                    value= {hobby.job_summary}
                                    // onChange={ondescription}
                                    onChange={(event) => handleEmployementChange(event, index, "job_summary")}
                                    placeholder={"Write something awesome..."}
                                    modules={modules} // add the modules prop
                               />
                      </div>
                  </div>
                    <div className="col-md-12  inputField">
                      <label htmlFor="job_accomplishments">Job Accomplishments</label>
                      {/* <textarea type="text" 
                      id="job_accomplishments" 
                      name="job_accomplishments" 
                      value= {employment.job_accomplishments}
                      onChange={(event) => handleEmployementChange(event, index, "job_accomplishments")}

                     />  */}

                   <TextArea rows={2}
                        id="job_accomplishments" 
                        name="job_accomplishments" 
                        value= {hobby.job_accomplishments}
                        onChange={(event) => handleEmployementChange(event, index, "job_accomplishments")} 
                   />
                    </div>
                    {/* { myEmployment.job_designation || myEmployment.employment_type || myEmployment.start_year || myEmployment.start_month || myEmployment.end_month || myEmployment.end_year || myEmployment.job_summary || myEmployment.job_accomplishments ?
               <Button type="primary" className="submit-btn">Submit</Button>
               : ''
              } */}

                    {/* <div className="col-md-12 "> 
                    <p className="float-left">Description</p>
                    </div>
                    <div className="col-md-12 inputField" style={{ height: 235 }}> 
                    
                      <div className='summary' style={{ height: 200 }}>
                               <ReactQuill
                                    theme="snow"
                                    value={userInfo.job_summary}
                               
                                    // onChange={ondescription}
                                    onChange={(event) => handleEmployementChange(event, index, "job_summary")}
                                    placeholder={"Write something awesome..."}
                                    modules={modules} // add the modules prop
                               />
                      </div>
                  </div> */}
              </div>
              
                </AccordionItemPanel>
              </AccordionItem>
            </Accordion>
          
          </div>
        ))}
          { employment.length !== 0  && ( employment[0].currently_working !== '' || employment[0].job_designation !== '' || employment[0].employment_type !== '' || employment[0].start_month !== '' || employment[0].start_year !== '' || employment[0].end_month !== '' || employment[0].end_year !== '' || employment[0].job_summary !== '' || employment[0].job_accomplishments !== '') ?
               <Button type="primary" className="submit-btn" onClick={handleApiCall}>Save</Button>
               : ''
              }  
      {!showEmployment && (
        <div className="add_education float-left">
          <button
            type="button"
            className="btn btn-default new-add"
            onClick={handleAddEmployment}
          >
            + Add Employment
          </button>
        </div>
      )}
      {showEmployment && (
        <>
          

          <div className="add_education float-left">
            <button
              type="button"
              className="btn btn-default new-add"
              onClick={handleAddEmployment}
            >
              +  Add one more employment
            </button>
          </div>

        </>
      )}
    </div>
  );
}

//const MemoizedSubComponent = React.memo(EmploymentForm);

export default memo(EmploymentForm)

